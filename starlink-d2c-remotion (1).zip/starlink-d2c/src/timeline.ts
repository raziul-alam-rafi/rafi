// timeline.ts — every frame number in the video is derived from the SRT here.
import { SRT_TEXT } from "./srtData";
import { parseSrt } from "./srt";
import { FPS } from "./config";
import { theme } from "./theme";

export const cues = parseSrt(SRT_TEXT);
const toF = (ms: number) => Math.round((ms / 1000) * FPS);

export const LEAD = Math.round(theme.timing.lead * FPS); // visuals land before the words
export const TAIL = Math.round(theme.timing.tail * FPS); // overlap for transitions
export const TOTAL_FRAMES = toF(cues[cues.length - 1].endMs);

// Scenes follow cue boundaries (1-based cue numbers, inclusive).
const SCENE_CUES: [number, number][] = [
  [1, 1], [2, 2], [3, 3], [4, 4], [5, 5], [6, 6], [7, 8],
];

export type SceneInfo = {
  no: number; // 1-based
  start: number; // first spoken frame (cue start)
  end: number; // last spoken frame (cue end)
  from: number; // Sequence start (includes LEAD)
  dur: number; // Sequence duration (includes TAIL)
};

export const scenes: SceneInfo[] = SCENE_CUES.map(([a, b], i) => {
  const start = toF(cues[a - 1].startMs);
  const end = toF(cues[b - 1].endMs);
  const from = i === 0 ? 0 : Math.max(0, start - LEAD);
  const to = i === SCENE_CUES.length - 1 ? TOTAL_FRAMES : Math.min(TOTAL_FRAMES, end + TAIL);
  return { no: i + 1, start, end, from, dur: to - from };
});

/** Absolute frame at a fraction of the scene's spoken range, minus LEAD (visual precedes speech). */
export const beat = (sceneNo: number, frac: number) => {
  const s = scenes[sceneNo - 1];
  return Math.max(0, s.start + Math.round(frac * (s.end - s.start)) - LEAD);
};
/** Same, but local to the scene's Sequence (for use inside scene components). */
export const lb = (sceneNo: number, frac: number) => beat(sceneNo, frac) - scenes[sceneNo - 1].from;
/** Scene-local frame of the scene's last spoken frame. */
export const sceneSpan = (sceneNo: number) => {
  const s = scenes[sceneNo - 1];
  return s.end - s.start;
};
