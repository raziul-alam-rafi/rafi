import React from "react";
import { Composition } from "remotion";
import { Main } from "./Main";
import { FPS, WIDTH, HEIGHT } from "./config";
import { TOTAL_FRAMES } from "./timeline";

export const RemotionRoot: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
