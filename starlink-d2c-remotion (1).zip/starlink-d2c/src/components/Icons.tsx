import React from "react";
import { theme } from "../theme";

type P = { size?: number; color?: string; accent?: string; sw?: number; style?: React.CSSProperties };
const base = (size: number, style?: React.CSSProperties) => ({ width: size, height: size, viewBox: "0 0 200 200", style: { overflow: "visible", ...style } as React.CSSProperties });
const line = { fill: "none", strokeLinecap: "round", strokeLinejoin: "round" } as const;

export const Satellite: React.FC<P> = ({ size = 200, color = theme.colors.text, accent = theme.colors.accent, sw = 5, style }) => (
  <svg {...base(size, style)}>
    <g transform="rotate(-35 100 100)" {...line} stroke={color} strokeWidth={sw}>
      <rect x="80" y="78" width="40" height="44" rx="9" fill={theme.colors.bgAlt} />
      <path d="M70 100 H80 M120 100 H130" />
      <rect x="10" y="82" width="60" height="36" rx="5" fill={theme.colors.bg} />
      <rect x="130" y="82" width="60" height="36" rx="5" fill={theme.colors.bg} />
      <path d="M30 82 V118 M50 82 V118 M150 82 V118 M170 82 V118" strokeWidth={sw * 0.6} stroke={accent} />
      <circle cx="100" cy="100" r="7" fill={accent} stroke="none" />
      <path d="M100 122 V138" />
      <circle cx="100" cy="142" r="5" fill={color} stroke="none" />
    </g>
  </svg>
);

export const WifiIcon: React.FC<P> = ({ size = 200, color = theme.colors.text, sw = 12, style }) => (
  <svg {...base(size, style)}>
    <g {...line} stroke={color} strokeWidth={sw}>
      <path d="M22 78 Q100 6 178 78" />
      <path d="M50 108 Q100 62 150 108" />
      <path d="M78 136 Q100 114 122 136" />
    </g>
    <circle cx="100" cy="164" r={sw * 0.95} fill={color} />
  </svg>
);

export const AntennaIcon: React.FC<P> = ({ size = 200, color = theme.colors.text, accent = theme.colors.accent, sw = 10, style }) => (
  <svg {...base(size, style)}>
    <g {...line} stroke={color} strokeWidth={sw}>
      <path d="M100 168 V66" />
      <path d="M78 176 H122" />
    </g>
    <circle cx="100" cy="56" r="11" fill={accent} />
    <g {...line} stroke={accent} strokeWidth={sw * 0.8}>
      <path d="M78 72 Q58 54 78 36" />
      <path d="M122 72 Q142 54 122 36" />
      <path d="M62 86 Q32 54 62 22" />
      <path d="M138 86 Q168 54 138 22" />
    </g>
  </svg>
);

export const TowerIcon: React.FC<P> = ({ size = 200, color = theme.colors.text, accent = theme.colors.accent, sw = 6, style }) => (
  <svg {...base(size, style)}>
    <g {...line} stroke={color} strokeWidth={sw}>
      <path d="M100 44 L52 180 M100 44 L148 180" />
      <path d="M87 80 H113 M74 120 H126 M61 160 H139" />
      <path d="M87 80 L126 120 M113 80 L74 120 M74 120 L139 160 M126 120 L61 160" strokeWidth={sw * 0.7} />
    </g>
    <circle cx="100" cy="36" r="9" fill={accent} />
    <g {...line} stroke={accent} strokeWidth={sw * 1.1}>
      <path d="M78 48 Q62 30 78 12" />
      <path d="M122 48 Q138 30 122 12" />
    </g>
  </svg>
);

export const ChatIcon: React.FC<P> = ({ size = 200, color = theme.colors.text, accent = theme.colors.accent, sw = 9, style }) => (
  <svg {...base(size, style)}>
    <g {...line} stroke={color} strokeWidth={sw}>
      <rect x="22" y="38" width="156" height="108" rx="30" />
      <path d="M68 146 L58 180 L104 146" />
    </g>
    <g fill={accent}><circle cx="68" cy="92" r="9" /><circle cx="100" cy="92" r="9" /><circle cx="132" cy="92" r="9" /></g>
  </svg>
);

export const GamepadIcon: React.FC<P> = ({ size = 200, color = theme.colors.text, accent = theme.colors.accent, sw = 9, style }) => (
  <svg {...base(size, style)}>
    <g {...line} stroke={color} strokeWidth={sw}>
      <rect x="14" y="58" width="172" height="96" rx="48" />
    </g>
    <g {...line} stroke={accent} strokeWidth={sw}>
      <path d="M52 106 H84 M68 90 V122" />
    </g>
    <circle cx="128" cy="98" r="9" fill={accent} /><circle cx="152" cy="116" r="9" fill={accent} />
  </svg>
);

export const PlayIcon: React.FC<P> = ({ size = 200, color = theme.colors.text, accent = theme.colors.accent, sw = 9, style }) => (
  <svg {...base(size, style)}>
    <rect x="18" y="42" width="164" height="116" rx="32" {...line} stroke={color} strokeWidth={sw} />
    <path d="M84 70 L84 130 L134 100 Z" fill={accent} stroke={accent} strokeWidth={sw * 0.8} strokeLinejoin="round" />
  </svg>
);

export const CheckMark: React.FC<P & { p?: number }> = ({ size = 120, color = theme.colors.accent, sw = 18, p = 1, style }) => (
  <svg {...base(size, style)}>
    <path d="M44 104 L86 146 L160 60" {...line} stroke={color} strokeWidth={sw} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
  </svg>
);

export const CrossMark: React.FC<P & { p?: number }> = ({ size = 120, color = theme.colors.textDim, sw = 18, p = 1, style }) => (
  <svg {...base(size, style)}>
    <path d="M56 56 L144 144" {...line} stroke={color} strokeWidth={sw} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - Math.min(1, p * 2)} />
    <path d="M144 56 L56 144" {...line} stroke={color} strokeWidth={sw} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - Math.max(0, p * 2 - 1)} />
  </svg>
);

// Material-style glyphs (24px grid)
export const ThumbUp: React.FC<P> = ({ size = 64, color = theme.colors.text, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={style}>
    <path fill={color} d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z" />
  </svg>
);
export const Bell: React.FC<P> = ({ size = 64, color = theme.colors.text, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={style}>
    <path fill={color} d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" />
  </svg>
);
export const Cursor: React.FC<P> = ({ size = 64, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 28" style={style}>
    <path d="M4 2 L4 22 L9 17.5 L12.5 25 L16 23.4 L12.6 16.2 L19 16 Z" fill={theme.colors.text} stroke={theme.colors.bg} strokeWidth="1.6" strokeLinejoin="round" />
  </svg>
);
