import React from "react";
import { AbsoluteFill, interpolate, random, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, tint } from "../theme";
import { scenes, LEAD, TAIL } from "../timeline";

/** Layer 1 — animated background mesh + twinkling stars. Never flat. */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height, fps } = useVideoConfig();
  const d1 = Math.sin(frame / (fps * 1.8)) * 60;
  const d2 = Math.cos(frame / (fps * 2.3)) * 50;
  const stars = React.useMemo(
    () =>
      Array.from({ length: 70 }).map((_, i) => ({
        x: random(`sx${i}`) * width,
        y: random(`sy${i}`) * height,
        r: 1 + random(`sr${i}`) * 2.2,
        ph: random(`sp${i}`) * 6.28,
      })),
    [width, height]
  );
  return (
    <AbsoluteFill style={{ background: `linear-gradient(160deg, ${theme.colors.bgAlt} 0%, ${theme.colors.bg} 45%, ${theme.colors.bgDeep} 100%)` }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -380 + d1, filter: "blur(60px)", background: `radial-gradient(circle, ${tint(theme.colors.primary, 0.26)}, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -460, right: -300 - d2, filter: "blur(70px)", background: `radial-gradient(circle, ${tint(theme.colors.accent, 0.16)}, transparent 65%)` }} />
      {stars.map((s, i) => (
        <div key={i} style={{ position: "absolute", left: s.x, top: s.y, width: s.r * 2, height: s.r * 2, borderRadius: "50%", background: theme.colors.text, opacity: 0.12 + 0.28 * (0.5 + 0.5 * Math.sin(frame / 22 + s.ph)) }} />
      ))}
    </AbsoluteFill>
  );
};

/** Layer 4 — colour grade (unifies everything). */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.2 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.22))" }} />
  </AbsoluteFill>
);

/** Layer 5a — procedural film grain. */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.06, mixBlendMode: "overlay" }} />
  );
};

/** Layer 5b — vignette (topmost). */
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.38) 100%)" }} />
);

/** Scene-to-scene mask wipe: a soft light band sweeps across at every cue boundary. */
export const TransitionWipes: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, fps } = useVideoConfig();
  const dur = Math.round(fps * 0.5);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      {scenes.slice(1).map((s) => {
        const t0 = s.from - 2; // sweep starts just as the new scene begins entering
        const p = interpolate(frame, [t0, t0 + dur], [0, 1], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        if (p <= 0 || p >= 1) return null;
        const x = interpolate(p, [0, 1], [-width * 0.6, width * 1.2]);
        return (
          <div key={s.no} style={{ position: "absolute", top: -100, bottom: -100, width: width * 0.5, left: 0, transform: `translateX(${x}px) skewX(-18deg)`, background: `linear-gradient(90deg, transparent, ${tint(theme.colors.primary, 0.22)} 50%, transparent)`, mixBlendMode: "screen", filter: "blur(12px)" }} />
        );
      })}
    </AbsoluteFill>
  );
};
export { LEAD, TAIL };
