import React from "react";
import { Audio, Sequence, staticFile, useVideoConfig } from "remotion";
import { beat, scenes } from "../timeline";
import { FR } from "../beats";

// Limited kit (5 sounds). Same event type → same sound, slight pitch variation on repeats.
type Kind = "pop" | "click" | "whoosh" | "chime" | "thud";
type Ev = { f: number; s: Kind; v?: number; r?: number };

const VOL: Record<Kind, number> = { pop: 0.3, click: 0.26, whoosh: 0.26, chime: 0.24, thud: 0.3 };

const mk = (markDelayFrames: number): Ev[] => [
  // S1 hook
  { f: 0, s: "thud" },
  { f: beat(1, FR.s1.line2) + 12, s: "pop", r: 1.04 },
  { f: beat(1, FR.s1.phone), s: "pop" },
  { f: beat(1, FR.s1.starlink), s: "chime" },
  // S2
  { f: beat(2, FR.s2.wifi) + 2, s: "pop", r: 0.96 },
  { f: beat(2, FR.s2.strike), s: "click" },
  { f: beat(2, FR.s2.lens) + 6, s: "pop", r: 1.05 },
  // S3
  { f: beat(3, FR.s3.meter) + 2, s: "pop", r: 0.98 },
  { f: beat(3, FR.s3.chat) + 4, s: "pop", r: 1.06 },
  { f: beat(3, FR.s3.sent), s: "click", r: 1.05 },
  // S4 (3 cards, equal spacing) + marks
  { f: beat(4, FR.s4.cards[0]), s: "pop", r: 1.0 },
  { f: beat(4, FR.s4.cards[0]) + markDelayFrames, s: "click" },
  { f: beat(4, FR.s4.cards[1]), s: "pop", r: 0.93 },
  { f: beat(4, FR.s4.cards[1]) + markDelayFrames, s: "pop", r: 0.72, v: 0.7 },
  { f: beat(4, FR.s4.cards[2]), s: "pop", r: 1.08 },
  { f: beat(4, FR.s4.cards[2]) + markDelayFrames, s: "pop", r: 0.72, v: 0.7 },
  // S5 regions + tower
  { f: beat(5, FR.s5.regions[0]), s: "pop", r: 0.94, v: 0.75 },
  { f: beat(5, FR.s5.regions[1]), s: "pop", r: 1.0, v: 0.75 },
  { f: beat(5, FR.s5.regions[2]), s: "pop", r: 1.07, v: 0.75 },
  { f: beat(5, FR.s5.tower), s: "chime", r: 0.9, v: 0.8 },
  // S6
  { f: beat(6, FR.s6.cross) + 8, s: "click", r: 0.95 },
  { f: beat(6, FR.s6.alert) + 4, s: "pop", r: 0.9 },
  { f: beat(6, FR.s6.path) + 10, s: "whoosh", v: 0.7 },
  { f: beat(6, FR.s6.starlink), s: "chime" },
  // S7
  { f: beat(7, FR.s7.title) + 3, s: "chime", r: 1.1 },
  { f: beat(7, FR.s7.cta) + 8, s: "pop", r: 1.0 },
  { f: beat(7, FR.s7.like), s: "click", r: 1.0 },
  { f: beat(7, FR.s7.sub), s: "click", r: 0.92 },
  // scene transitions: soft whoosh as the wipe begins
  ...scenes.slice(1).map((s): Ev => ({ f: Math.max(0, s.from - 2), s: "whoosh" })),
];

export const Sfx: React.FC = () => {
  const { fps } = useVideoConfig();
  const mark = Math.round(FR.s4.markDelaySec * fps);
  const events = mk(mark);
  return (
    <>
      {events.map((e, i) => (
        <Sequence key={i} from={Math.max(0, e.f)} durationInFrames={Math.ceil(fps * 1.0)} layout="none">
          <Audio src={staticFile(`sfx/${e.s}.wav`)} volume={VOL[e.s] * (e.v ?? 1)} playbackRate={e.r ?? 1} />
        </Sequence>
      ))}
    </>
  );
};
