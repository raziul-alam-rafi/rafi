import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** spring progress 0→1 starting at `delay` (scene-local frames). */
export const useSpring = (delay = 0, config: Record<string, number> = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config });
};

/** Bezier progress 0→1 over `secs` seconds starting at `delay`. */
export const useEase = (delay: number, secs: number, easing = theme.ease.out) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return interpolate(frame, [delay, delay + secs * fps], [0, 1], { easing, ...clamp });
};

/** Entrance = opacity + rise + scale (+ optional exit at `exitAt`, faster than entrance). */
export const Entrance: React.FC<{
  delay?: number; y?: number; x?: number; from?: number; exitAt?: number;
  config?: Record<string, number>; style?: React.CSSProperties; children: React.ReactNode;
}> = ({ delay = 0, y = 40, x = 0, from = 0.94, exitAt, config = theme.spring.smooth, style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config });
  const exitLen = Math.round(theme.timing.exit * fps);
  const e = exitAt === undefined ? 0 : interpolate(frame, [exitAt, exitAt + exitLen], [0, 1], { easing: theme.ease.in, ...clamp });
  return (
    <div style={{ opacity: p * (1 - e), transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${interpolate(p, [0, 1], [y, 0]) - e * 30}px) scale(${interpolate(p, [0, 1], [from, 1]) * (1 - e * 0.05)})`, ...style }}>
      {children}
    </div>
  );
};

export type W = { t: string; style?: React.CSSProperties; pop?: boolean };

/** Word-by-word staggered reveal. Splits on spaces ONLY — never inside Bengali words. */
export const Words: React.FC<{
  words: W[]; delay?: number; per?: number; exitAt?: number; gap?: number;
  style?: React.CSSProperties; align?: "center" | "flex-start";
}> = ({ words, delay = 0, per = 4, exitAt, gap = 30, style, align = "center" }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const exitLen = Math.round(theme.timing.exit * fps);
  return (
    <div style={{ display: "flex", flexWrap: "wrap", justifyContent: align, columnGap: gap, rowGap: 6, fontFamily: theme.fonts.display, fontWeight: theme.weight.display, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.text, ...style }}>
      {words.map((w, i) => {
        const d = delay + i * per;
        const p = spring({ frame: frame - d, fps, config: w.pop ? theme.spring.bouncy : theme.spring.snappy });
        const e = exitAt === undefined ? 0 : interpolate(frame, [exitAt + i * 2, exitAt + i * 2 + exitLen], [0, 1], { easing: theme.ease.in, ...clamp });
        return (
          <span key={i} style={{ display: "inline-block", opacity: Math.min(1, p * 1.4) * (1 - e), transform: `translateY(${interpolate(p, [0, 1], [34, 0]) - e * 34}px) scale(${interpolate(p, [0, 1], [w.pop ? 0.6 : 0.92, 1])})`, ...w.style }}>
            {w.t}
          </span>
        );
      })}
    </div>
  );
};

/** Line mask reveal: text rises out of a clipped box. */
export const MaskLine: React.FC<{ delay?: number; style?: React.CSSProperties; children: React.ReactNode }> = ({ delay = 0, style, children }) => {
  const p = useEase(delay, 0.6, theme.ease.out);
  return (
    <div style={{ overflow: "hidden", paddingTop: "0.22em", paddingBottom: "0.3em", marginTop: "-0.22em", marginBottom: "-0.3em", color: theme.colors.text, fontFamily: theme.fonts.display, fontWeight: theme.weight.display, ...style }}>
      <div style={{ transform: `translateY(${(1 - p) * 110}%)`, opacity: Math.min(1, p * 3) }}>{children}</div>
    </div>
  );
};

/** Highlight sweep: a pill swipes in behind the word. */
export const Sweep: React.FC<{ delay: number; color?: string; children: React.ReactNode; style?: React.CSSProperties }> = ({ delay, color = theme.colors.primary, children, style }) => {
  const p = useEase(delay, 0.5, theme.ease.out);
  return (
    <span style={{ position: "relative", display: "inline-block", padding: "0 0.28em", ...style }}>
      <span style={{ position: "absolute", inset: "0.12em 0 0.04em 0", background: color, borderRadius: theme.radius.small, transformOrigin: "left center", transform: `scaleX(${p})`, boxShadow: `0 0 60px ${theme.colors.glow}` }} />
      <span style={{ position: "relative" }}>{children}</span>
    </span>
  );
};

/** Gradient keyword text (hero → accent). */
export const gradientText: React.CSSProperties = {
  background: `linear-gradient(100deg, ${theme.colors.primary} 0%, ${theme.colors.accent} 100%)`,
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
  WebkitTextFillColor: "transparent",
};

/** Idle breathing so nothing on screen sits dead still. */
export const Float: React.FC<{ amp?: number; speed?: number; phase?: number; scale?: number; style?: React.CSSProperties; children: React.ReactNode }> = ({ amp = 6, speed = 30, phase = 0, scale = 0.012, style, children }) => {
  const frame = useCurrentFrame();
  return (
    <div style={{ transform: `translateY(${Math.sin(frame / speed + phase) * amp}px) scale(${1 + Math.sin(frame / (speed * 0.75) + phase) * scale})`, ...style }}>{children}</div>
  );
};

/** Scene-local exit for a block: faster than entrance, 3 properties. */
export const Exit: React.FC<{ at: number; style?: React.CSSProperties; children: React.ReactNode }> = ({ at, style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const len = Math.round(theme.timing.exit * fps);
  const e = interpolate(frame, [at, at + len], [0, 1], { easing: theme.ease.in, ...clamp });
  if (e >= 1) return null;
  return (
    <div style={{ position: "absolute", inset: 0, opacity: 1 - e, transform: `translateY(${-e * 40}px) scale(${1 + e * 0.05})`, filter: `blur(${e * 10}px)`, ...style }}>
      {children}
    </div>
  );
};

/** Expanding rings (signal / alert pulse). Centered on its parent's origin. */
export const Rings: React.FC<{ at: number; count?: number; size?: number; color?: string; period?: number; width?: number }> = ({ at, count = 3, size = 600, color = theme.colors.accent, period = 1.6, width = 4 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const per = period * fps;
  return (
    <>
      {Array.from({ length: count }).map((_, i) => {
        const t = frame - at - (i * per) / count;
        if (t < 0) return null;
        const p = (t % per) / per;
        const e = theme.ease.out(p);
        return (
          <div key={i} style={{ position: "absolute", left: "50%", top: "50%", width: size, height: size, marginLeft: -size / 2, marginTop: -size / 2, borderRadius: "50%", border: `${width}px solid ${color}`, opacity: (1 - p) * 0.7, transform: `scale(${0.15 + e * 0.85})`, pointerEvents: "none" }} />
        );
      })}
    </>
  );
};

/** Dashed beam that draws from A to B, then keeps flowing. Coordinates in px. */
export const Beam: React.FC<{ a: [number, number]; b: [number, number]; at: number; color?: string; width?: number; secs?: number }> = ({ a, b, at, color = theme.colors.accent, width = 6, secs = 0.7 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = interpolate(frame, [at, at + secs * fps], [0, 1], { easing: theme.ease.inOut, ...clamp });
  if (p <= 0) return null;
  const x2 = a[0] + (b[0] - a[0]) * p;
  const y2 = a[1] + (b[1] - a[1]) * p;
  return (
    <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", overflow: "visible", pointerEvents: "none" }}>
      <line x1={a[0]} y1={a[1]} x2={x2} y2={y2} stroke={color} strokeWidth={width} strokeLinecap="round" strokeDasharray="4 22" strokeDashoffset={-frame * 3} style={{ filter: `drop-shadow(0 0 10px ${color})` }} />
    </svg>
  );
};
