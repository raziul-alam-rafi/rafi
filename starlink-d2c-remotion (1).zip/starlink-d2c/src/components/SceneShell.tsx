import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

/** Wraps every scene: staged entrance (opacity + scale + blur) and a faster exit. */
export const SceneShell: React.FC<{ children: React.ReactNode; hold?: boolean }> = ({ children, hold }) => {
  const frame = useCurrentFrame();
  const { durationInFrames, fps } = useVideoConfig();
  const inLen = Math.round(theme.timing.entrance * fps * 0.6);
  const outLen = Math.round(theme.timing.exit * fps);
  const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
  const pin = interpolate(frame, [0, inLen], [0, 1], { easing: theme.ease.out, ...clamp });
  const pout = hold ? 0 : interpolate(frame, [durationInFrames - outLen, durationInFrames - 1], [0, 1], { easing: theme.ease.in, ...clamp });
  // last scene holds its final frame (clean ending) — no exit
  return (
    <AbsoluteFill
      style={{
        opacity: pin * (1 - pout),
        transform: `scale(${interpolate(pin, [0, 1], [0.97, 1]) * interpolate(pout, [0, 1], [1, 1.04])}) translateY(${interpolate(pout, [0, 1], [0, -26])}px)`,
        filter: `blur(${interpolate(pin, [0, 1], [8, 0]) + interpolate(pout, [0, 1], [0, 10])}px)`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
