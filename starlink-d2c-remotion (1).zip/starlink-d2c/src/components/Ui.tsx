import React from "react";
import { theme } from "../theme";

/** Glass card — the single card look used across the whole video. */
export const Glass: React.FC<{ style?: React.CSSProperties; children?: React.ReactNode }> = ({ style, children }) => (
  <div style={{ background: `linear-gradient(145deg, ${theme.colors.glassStrong}, ${theme.colors.glass})`, border: `1.5px solid ${theme.colors.glassBorder}`, borderRadius: theme.radius.card, boxShadow: theme.shadow.card, backdropFilter: "blur(18px)", ...style }}>
    {children}
  </div>
);

/** Glossy phone mockup (CSS only). */
export const PhoneMockup: React.FC<{ width?: number; glow?: boolean; style?: React.CSSProperties; children?: React.ReactNode }> = ({ width = 360, glow, style, children }) => {
  const h = width * 2.05;
  return (
    <div style={{ position: "relative", width, height: h, borderRadius: width * 0.14, padding: width * 0.03, background: `linear-gradient(150deg, ${theme.colors.glassBorder}, ${theme.colors.glass})`, border: `2px solid ${theme.colors.glassBorder}`, boxShadow: glow ? `0 0 80px ${theme.colors.glow}, ${theme.shadow.card}` : theme.shadow.card, ...style }}>
      <div style={{ position: "relative", width: "100%", height: "100%", borderRadius: width * 0.115, overflow: "hidden", background: `linear-gradient(170deg, ${theme.colors.bgAlt}, ${theme.colors.bgDeep})` }}>
        <div style={{ position: "absolute", top: width * 0.035, left: "50%", width: width * 0.3, height: width * 0.075, marginLeft: -width * 0.15, borderRadius: 99, background: theme.colors.bgDeep, zIndex: 3 }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(120deg, rgba(255,255,255,0.10), transparent 38%)", zIndex: 2, pointerEvents: "none" }} />
        {children}
      </div>
    </div>
  );
};

/** Signal bars (status-bar style). level 0..4 */
export const SignalBars: React.FC<{ level: number; size?: number; color?: string }> = ({ level, size = 40, color = theme.colors.text }) => (
  <div style={{ display: "flex", alignItems: "flex-end", gap: size * 0.1, height: size }}>
    {[0.3, 0.52, 0.76, 1].map((h, i) => (
      <div key={i} style={{ width: size * 0.17, height: size * h, borderRadius: 3, background: color, opacity: i < level ? 1 : 0.2 }} />
    ))}
  </div>
);

export const Pill: React.FC<{ style?: React.CSSProperties; children: React.ReactNode }> = ({ style, children }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 14, padding: "10px 30px 14px", borderRadius: theme.radius.pill, background: theme.colors.glassStrong, border: `1.5px solid ${theme.colors.glassBorder}`, fontFamily: theme.fonts.body, fontWeight: theme.weight.body, fontSize: theme.size.caption, color: theme.colors.text, lineHeight: 1.3, ...style }}>
    {children}
  </div>
);
