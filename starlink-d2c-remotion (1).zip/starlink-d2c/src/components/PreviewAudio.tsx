import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { VOICEOVER_IN_RENDER, VOICEOVER_PREVIEW } from "../config";

/**
 * Plays public/voiceover.mp3 if it exists; silently does nothing if it does not.
 * Studio preview: controlled by VOICEOVER_PREVIEW. Render: controlled by VOICEOVER_IN_RENDER (default off).
 */
const enabled = () => {
  const { isRendering } = getRemotionEnvironment();
  return isRendering ? VOICEOVER_IN_RENDER : VOICEOVER_PREVIEW;
};

export const PreviewAudio: React.FC = () => {
  const on = enabled();
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => (on ? delayRender("voiceover check") : null));

  useEffect(() => {
    if (!on || handle === null) return;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") || "";
        setOk(r.ok && !type.includes("text/html"));
      })
      .catch(() => setOk(false))
      .finally(() => continueRender(handle));
  }, [on, handle]);

  if (!on || !ok) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
