import React from "react";
import { random, useCurrentFrame } from "remotion";
import { theme, tint } from "../theme";

export const REGION_W = 1920;
// Parallax speeds per layer. Region k of a layer sits at k*REGION_W*speed, so every
// region is centred on screen exactly when the camera arrives there.
export const PARALLAX = { far: 0.9, mid: 0.95, near: 1 } as const;
const H = 1080;

// Ridge line whose first/last points sit on `edgeY`, so neighbouring regions join without a cliff.
const ridge = (x0: number, w: number, base: number, amp: number, n: number, seed: string, jag = 1, edgeY = base) => {
  const pts: string[] = [`M${x0} ${H}`];
  for (let i = 0; i <= n; i++) {
    const x = x0 + (w * i) / n;
    const peak = i % 2 === 0;
    const y = i === 0 || i === n ? edgeY : base - amp * (0.25 + random(`${seed}${i}`) * 0.75) * (peak ? 1 : 0.35 * jag);
    pts.push(`L${x} ${y}`);
  }
  pts.push(`L${x0 + w} ${H} Z`);
  return pts.join(" ");
};

const trees = (x0: number, w: number, base: number, size: number, n: number, seed: string) =>
  Array.from({ length: n }).map((_, i) => {
    const cx = x0 + (w * (i + random(`${seed}x${i}`) * 0.6)) / n;
    const s = size * (0.7 + random(`${seed}s${i}`) * 0.7);
    return `M${cx - s * 0.55} ${base} L${cx} ${base - s * 2.1} L${cx + s * 0.55} ${base} Z`;
  });

/** Layer: far / mid / near. Each is 3 regions wide (mountains | forest | sea). */
export const LandscapeLayer: React.FC<{ layer: "far" | "mid" | "near" }> = ({ layer }) => {
  const frame = useCurrentFrame();
  const ox = (k: number) => k * REGION_W * PARALLAX[layer];
  const c = theme.colors;
  const W = REGION_W * 3;
  // waves fade in from the left edge of the sea region so there is no vertical seam
  const wave = (y: number, amp: number, ph: number, alpha: number, k: number, id: string) => {
    const x0 = ox(2) - 400;
    let d = `M${x0} ${H}`;
    for (let x = 0; x <= REGION_W + 400; x += 40) {
      d += ` L${x0 + x} ${y + Math.sin(x / 90 + frame / k + ph) * amp * Math.min(1, x / 400)}`;
    }
    d += ` L${x0 + REGION_W + 400} ${H} Z`;
    return (
      <>
        <defs>
          <linearGradient id={id} x1="0" x2="1" y1="0" y2="0">
            <stop offset="0" stopColor={c.accent} stopOpacity="0" />
            <stop offset="0.22" stopColor={c.accent} stopOpacity={alpha} />
            <stop offset="1" stopColor={c.accent} stopOpacity={alpha} />
          </linearGradient>
        </defs>
        <path d={d} fill={`url(#${id})`} />
      </>
    );
  };
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
      {layer === "far" && (
        <>
          <path d={ridge(0, REGION_W, 620, 330, 9, "fm", 1, 700)} fill={tint(c.primary, 0.22)} />
          <path d={ridge(ox(1), REGION_W, 680, 170, 12, "ff", 2.2, 700)} fill={tint(c.primary, 0.18)} />
          <defs>
            <linearGradient id="seaFade" x1="0" x2="1" y1="0" y2="0">
              <stop offset="0" stopColor={c.accent} stopOpacity="0" />
              <stop offset="0.35" stopColor={c.accent} stopOpacity="0.07" />
              <stop offset="1" stopColor={c.accent} stopOpacity="0.07" />
            </linearGradient>
          </defs>
          <rect x={ox(2)} y={700} width={REGION_W} height={H} fill={tint(c.primary, 0.18)} />
          <rect x={ox(2) - 500} y={700} width={REGION_W + 500} height={H} fill="url(#seaFade)" />
          <circle cx={ox(2) + 1250} cy={600} r={150} fill={tint(c.text, 0.1)} />
        </>
      )}
      {layer === "mid" && (
        <>
          <path d={ridge(0, REGION_W, 760, 400, 8, "mm", 1, 800)} fill={c.bgAlt} />
          <path d={ridge(0, REGION_W, 760, 400, 8, "mm", 1, 800)} fill={tint(c.primary, 0.22)} />
          <rect x={ox(1)} y={800} width={REGION_W} height={H} fill={tint(c.primary, 0.1)} />
          {trees(ox(1), REGION_W, 800, 46, 26, "tm").map((d, i) => (<path key={i} d={d} fill={tint(c.accent, 0.2)} />))}
          {wave(790, 10, 0, 0.14, 26, "w1")}
        </>
      )}
      {layer === "near" && (
        <>
          <path d={ridge(0, REGION_W, 930, 190, 7, "mn", 1.4, 960)} fill={c.bgDeep} />
          <rect x={ox(1)} y={960} width={REGION_W} height={H} fill={c.bgDeep} />
          {trees(ox(1), REGION_W, 960, 92, 14, "tn").map((d, i) => (<path key={i} d={d} fill={c.bgDeep} />))}
          {wave(880, 14, 1.2, 0.2, 22, "w2")}
          {wave(960, 18, 2.4, 0.3, 18, "w3")}
        </>
      )}
    </svg>
  );
};
