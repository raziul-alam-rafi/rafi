// theme.ts — single source of truth: colors, fonts, easings, springs, sizes.
// Scheme: "Deep Space" (user pick #1). Components never inline hex / easing / spring.
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#060B1A",
    bgAlt: "#0B1430",
    bgDeep: "#030612",
    primary: "#3B82F6", // THE hero color — max one hero element per frame
    accent: "#22D3EE",
    text: "#F1F5F9",
    textDim: "#94A3B8",
    textFaint: "#52627F",
    glass: "rgba(255,255,255,0.06)",
    glassStrong: "rgba(255,255,255,0.10)",
    glassBorder: "rgba(255,255,255,0.14)",
    glow: "rgba(59,130,246,0.45)",
  },
  fonts: {
    display: "'Hind Siliguri', sans-serif",
    body: "'Hind Siliguri', sans-serif",
  },
  weight: { display: 700, body: 600 },
  size: { hero: 200, h1: 150, h2: 100, h3: 68, body: 52, caption: 40 },
  radius: { card: 40, pill: 999, small: 22 },
  shadow: {
    card: "0 40px 90px -24px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.05) inset",
    soft: "0 20px 50px -18px rgba(0,0,0,0.6)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  // seconds — converted to frames with fps
  timing: { lead: 0.17, tail: 0.2, entrance: 0.7, exit: 0.33 },
} as const;

/** "#RRGGBB" + alpha -> rgba(). Keeps every tint derived from theme colors. */
export const tint = (hex: string, a: number) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};
