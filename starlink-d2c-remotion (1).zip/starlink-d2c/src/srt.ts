export type Cue = { index: number; startMs: number; endMs: number; text: string };

const toMs = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) return 0;
  return ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * 1000 + +m[4];
};

export const parseSrt = (raw: string): Cue[] =>
  raw
    .replace(/\r/g, "")
    .split(/\n\s*\n/)
    .map((block) => block.trim().split("\n"))
    .filter((l) => l.length >= 2 && l[1].includes("-->"))
    .map((l) => {
      const [a, b] = l[1].split("-->");
      return {
        index: parseInt(l[0], 10),
        startMs: toMs(a),
        endMs: toMs(b),
        text: l.slice(2).join(" ").trim(),
      };
    });
