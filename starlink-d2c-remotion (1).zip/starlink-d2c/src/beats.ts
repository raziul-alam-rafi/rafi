// beats.ts — named moments as FRACTIONS of each scene's spoken range (SRT-derived).
// Visuals and SFX both read from here, so they can never drift apart.
export const FR = {
  s1: { line2: 0.17, kineticOut: 0.36, phone: 0.4, starlink: 0.52 },
  s2: { wifi: 0.0, strike: 0.3, lens: 0.42, small: 0.76 },
  s3: { meter: 0.0, limited: 0.3, chat: 0.42, bubble: 0.6, sent: 0.82 },
  s4: { cards: [0.04, 0.36, 0.68], markDelaySec: 0.3 }, // equal spacing across the cue
  s5: { regions: [0.04, 0.27, 0.5], stuck: 0.66, tower: 0.84 }, // equal spacing
  s6: { cross: 0.0, alert: 0.12, path: 0.46, starlink: 0.8 },
  s7: { title: 0.0, cta: 0.27, like: 0.55, sub: 0.76 },
} as const;
