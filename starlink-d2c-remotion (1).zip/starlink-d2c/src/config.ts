// Project-wide video settings. Change here only.
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Voiceover (optional): drop your narration at public/voiceover.mp3
// - Studio preview: plays if the file exists, silently skipped if not.
// - Render: OFF by default. Set VOICEOVER_IN_RENDER = true to bake it into the MP4.
export const VOICEOVER_PREVIEW = true;
export const VOICEOVER_IN_RENDER = false;
