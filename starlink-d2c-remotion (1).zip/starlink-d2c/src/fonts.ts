// Offline fonts: files live in public/fonts (no network needed).
import { staticFile, delayRender, continueRender } from "remotion";

const BN = "U+0951-0952,U+0964-0965,U+0980-09FE,U+1CD0,U+1CD2,U+1CD5-1CD6,U+1CD8,U+1CE1,U+1CEA,U+1CED,U+1CF2,U+1CF5-1CF7,U+200C-200D,U+20B9,U+25CC,U+A8F1";
const LT = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD";
const faces = [
  { w: 600, s: "latin", r: LT },
  { w: 600, s: "bengali", r: BN },
  { w: 700, s: "latin", r: LT },
  { w: 700, s: "bengali", r: BN },
];

// Bengali declared last so danda (U+0964), ZWJ/ZWNJ and conjuncts resolve from the Bengali file.
const css = faces
  .map(
    (f) => `@font-face{font-family:'Hind Siliguri';font-weight:${f.w};font-style:normal;font-display:block;` +
      `src:url('${staticFile(`fonts/hind-siliguri-${f.s}-${f.w}-normal.woff2`)}') format('woff2');unicode-range:${f.r};}`
  )
  .join("\n");

let started = false;
export const loadFonts = () => {
  if (started || typeof document === "undefined") return;
  started = true;
  const handle = delayRender("fonts");
  const style = document.createElement("style");
  style.textContent = css;
  document.head.appendChild(style);
  Promise.all([
    document.fonts.load("700 60px 'Hind Siliguri'", "আ ক্ষ্ম Aa"),
    document.fonts.load("600 40px 'Hind Siliguri'", "আ ক্ষ্ম Aa"),
  ])
    .catch(() => undefined)
    .finally(() => continueRender(handle));
};
