import React, { useState } from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { scenes } from "./timeline";
import { loadFonts } from "./fonts";
import { BgMesh, Grade, Grain, Vignette, TransitionWipes } from "./components/Layers";
import { SceneShell } from "./components/SceneShell";
import { Sfx } from "./components/Sfx";
import { PreviewAudio } from "./components/PreviewAudio";
import { Scene1 } from "./scenes/Scene1";
import { Scene2 } from "./scenes/Scene2";
import { Scene3 } from "./scenes/Scene3";
import { Scene4 } from "./scenes/Scene4";
import { Scene5 } from "./scenes/Scene5";
import { Scene6 } from "./scenes/Scene6";
import { Scene7 } from "./scenes/Scene7";

const SCENES = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7];

export const Main: React.FC = () => {
  useState(() => loadFonts());
  return (
    <AbsoluteFill style={{ backgroundColor: theme.colors.bg, fontFamily: theme.fonts.display, color: theme.colors.text }}>
      {/* layer 1: background mesh */}
      <BgMesh />
      {/* layers 2–3: assets + graphics/type (per scene) */}
      {scenes.map((s, i) => {
        const C = SCENES[i];
        return (
          <Sequence key={s.no} from={s.from} durationInFrames={s.dur} name={`Scene ${s.no}`}>
            <SceneShell hold={i === scenes.length - 1}>
              <C />
            </SceneShell>
          </Sequence>
        );
      })}
      <TransitionWipes />
      {/* layer 4: colour grade, layer 5: grain + vignette */}
      <Grade />
      <Grain />
      <Vignette />
      {/* sound */}
      <Sfx />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
