import React from "react";
import { AbsoluteFill, interpolate, useVideoConfig } from "remotion";
import { theme, tint } from "../theme";
import { lb } from "../timeline";
import { FR } from "../beats";
import { Entrance, Float, useSpring, useEase } from "../components/Anim";
import { Glass } from "../components/Ui";
import { ChatIcon, GamepadIcon, PlayIcon, CheckMark, CrossMark } from "../components/Icons";

// Style: Checklist cards (what works / what does not)
type Item = { label: string; badge: string; ok: boolean; icon: React.ReactNode };

const Card: React.FC<{ item: Item; t: number; markDelay: number; i: number }> = ({ item, t, markDelay, i }) => {
  const p = useSpring(t, theme.spring.bouncy);
  const mark = useEase(t + markDelay, 0.4, theme.ease.out);
  const dim = item.ok ? 0 : mark;
  return (
    <div style={{ opacity: Math.min(1, p * 1.5), transform: `translateY(${interpolate(p, [0, 1], [90, 0])}px) scale(${interpolate(p, [0, 1], [0.85, 1])}) rotate(${interpolate(p, [0, 1], [i === 1 ? 0 : i === 0 ? -4 : 4, 0])}deg)` }}>
      <Float amp={7} speed={30} phase={i * 1.7}>
        <Glass style={{ width: 500, height: 660, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 26, boxShadow: item.ok ? `0 0 90px ${theme.colors.glow}, ${theme.shadow.card}` : theme.shadow.card, border: item.ok ? `2px solid ${tint(theme.colors.primary, 0.8)}` : `1.5px solid ${theme.colors.glassBorder}`, opacity: 1 - dim * 0.3 }}>
          <div style={{ position: "relative", width: 250, height: 250, opacity: 1 - dim * 0.6 }}>
            {item.icon}
            {!item.ok && (
              <div style={{ position: "absolute", inset: -10, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <CrossMark size={300} p={mark} color={theme.colors.text} sw={14} />
              </div>
            )}
          </div>
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.h3 + 8, lineHeight: 1.3 }}>{item.label}</div>
          <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "8px 30px 12px 22px", borderRadius: 99, background: item.ok ? tint(theme.colors.accent, 0.2) : theme.colors.glass, border: `1.5px solid ${item.ok ? tint(theme.colors.accent, 0.6) : theme.colors.glassBorder}`, fontFamily: theme.fonts.body, fontWeight: theme.weight.body, fontSize: 40, lineHeight: 1.35, color: item.ok ? theme.colors.accent : theme.colors.textDim }}>
            {item.ok ? <CheckMark size={52} p={mark} sw={22} /> : <CrossMark size={44} p={mark} color={theme.colors.textDim} sw={20} />}
            {item.badge}
          </div>
        </Glass>
      </Float>
    </div>
  );
};

export const Scene4: React.FC = () => {
  const { fps } = useVideoConfig();
  const markDelay = Math.round(FR.s4.markDelaySec * fps);
  const items: Item[] = [
    { label: "Message", badge: "পাওয়া যাচ্ছে", ok: true, icon: <ChatIcon size={250} /> },
    { label: "Game খেলা", badge: "প্রায় অসম্ভব", ok: false, icon: <GamepadIcon size={250} color={theme.colors.textDim} accent={theme.colors.textFaint} /> },
    { label: "Video দেখা", badge: "প্রায় অসম্ভব", ok: false, icon: <PlayIcon size={250} color={theme.colors.textDim} accent={theme.colors.textFaint} /> },
  ];
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
      <div style={{ display: "flex", gap: 64 }}>
        {items.map((it, i) => (
          <Card key={i} i={i} item={it} t={lb(4, FR.s4.cards[i])} markDelay={markDelay} />
        ))}
      </div>
    </AbsoluteFill>
  );
};
