import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, tint } from "../theme";
import { lb } from "../timeline";
import { FR } from "../beats";
import { Words, Entrance, MaskLine, gradientText, Float, Exit, Rings, useSpring, useEase } from "../components/Anim";
import { Glass, Pill } from "../components/Ui";
import { CheckMark } from "../components/Icons";

// Style: Glass Cards — signal meter (limited) → Glossy chat UI (messages only)
const SEGMENTS = 12;
const FILLED = 3;

export const Scene3: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tMeter = lb(3, FR.s3.meter);
  const tLimited = lb(3, FR.s3.limited);
  const tChat = lb(3, FR.s3.chat);
  const tBubble = lb(3, FR.s3.bubble);
  const tSent = lb(3, FR.s3.sent);
  const pCard = useSpring(tMeter + 2, theme.spring.smooth);
  const pChat = useSpring(tChat + 4, theme.spring.smooth);
  const pBubble = useSpring(tBubble, theme.spring.snappy);
  const check = useEase(tSent, 0.35, theme.ease.out);

  // typewriter, word by word (Bengali never split inside a word)
  const msg = ["আমি", "ঠিক", "আছি"];
  const per = Math.round(fps * 0.16);
  const shown = Math.max(0, Math.min(msg.length, Math.floor((frame - tBubble - 6) / per) + 1));
  const typing = frame >= tBubble && shown < msg.length;

  return (
    <AbsoluteFill>
      {/* ---------- Phase A: limited signal ---------- */}
      <Exit at={tChat - 2}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 36 }}>
            <div style={{ opacity: pCard, transform: `translateY(${interpolate(pCard, [0, 1], [60, 0])}px) scale(${interpolate(pCard, [0, 1], [0.94, 1])})` }}>
              <Float amp={5} speed={30}>
                <Glass style={{ width: 1240, padding: "48px 64px 56px" }}>
                  <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.h3, color: theme.colors.textDim, lineHeight: 1.3, marginBottom: 34 }}>সিগন্যাল ক্ষমতা</div>
                  <div style={{ display: "flex", gap: 14 }}>
                    {Array.from({ length: SEGMENTS }).map((_, i) => {
                      const on = i < FILLED;
                      const p = useSpring(tMeter + 8 + i * 3, theme.spring.snappy);
                      return (
                        <div key={i} style={{ flex: 1, height: 120, borderRadius: 18, background: on ? theme.colors.accent : theme.colors.glassStrong, opacity: on ? Math.min(1, p * 1.5) : 0.9, transform: `scaleY(${interpolate(p, [0, 1], [0.3, 1])})`, transformOrigin: "bottom", boxShadow: on ? `0 0 34px ${tint(theme.colors.accent, 0.55)}` : "none" }} />
                      );
                    })}
                  </div>
                </Glass>
              </Float>
            </div>
            <Entrance delay={tLimited} y={50} from={0.7} config={theme.spring.bouncy}>
              <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.hero * 0.9, lineHeight: 1.3, ...gradientText, filter: `drop-shadow(0 0 36px ${theme.colors.glow})` }}>সীমিত</div>
            </Entrance>
          </div>
        </AbsoluteFill>
      </Exit>

      {/* ---------- Phase B: Message UI ---------- */}
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 150, top: 330, fontFamily: theme.fonts.display, fontWeight: theme.weight.display }}>
          <MaskLine delay={tChat} style={{ fontSize: theme.size.h3, color: theme.colors.textDim, lineHeight: 1.3 }}>শুরুতে মূলত</MaskLine>
          <Entrance delay={tChat + 6} y={60} from={0.8} config={theme.spring.bouncy} style={{ transformOrigin: "left center" }}>
            <div style={{ fontSize: 190, lineHeight: 1.25, ...gradientText, filter: `drop-shadow(0 0 40px ${theme.colors.glow})` }}>Message</div>
          </Entrance>
          <MaskLine delay={tChat + 16} style={{ fontSize: theme.size.h2, lineHeight: 1.3 }}>আদান-প্রদান</MaskLine>
        </div>

        <div style={{ position: "absolute", left: 1130, top: 150, width: 640, opacity: pChat, transform: `translateY(${interpolate(pChat, [0, 1], [80, 0])}px) scale(${interpolate(pChat, [0, 1], [0.93, 1])})` }}>
          <Float amp={6} speed={32}>
            <Glass style={{ height: 780, padding: 36, display: "flex", flexDirection: "column", gap: 26 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 18, paddingBottom: 22, borderBottom: `1.5px solid ${theme.colors.glassBorder}` }}>
                <div style={{ width: 62, height: 62, borderRadius: "50%", background: theme.colors.glassStrong, border: `1.5px solid ${theme.colors.glassBorder}` }} />
                <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.caption + 6, lineHeight: 1.3 }}>Message</div>
              </div>
              {/* incoming skeleton bubble */}
              <Entrance delay={tChat + 14} y={26} config={theme.spring.snappy} style={{ alignSelf: "flex-start" }}>
                <div style={{ padding: "26px 30px", borderRadius: 30, borderTopLeftRadius: 8, background: theme.colors.glass, border: `1.5px solid ${theme.colors.glassBorder}`, display: "flex", flexDirection: "column", gap: 14 }}>
                  <div style={{ width: 300, height: 16, borderRadius: 8, background: theme.colors.glassBorder }} />
                  <div style={{ width: 190, height: 16, borderRadius: 8, background: theme.colors.glassBorder }} />
                </div>
              </Entrance>
              <div style={{ flex: 1 }} />
              {/* outgoing typed bubble */}
              <div style={{ alignSelf: "flex-end", opacity: Math.min(1, pBubble * 1.5), transform: `translateY(${interpolate(pBubble, [0, 1], [30, 0])}px) scale(${interpolate(pBubble, [0, 1], [0.9, 1])})`, transformOrigin: "bottom right" }}>
                <div style={{ minWidth: 210, minHeight: 92, padding: "14px 34px 20px", borderRadius: 34, borderBottomRightRadius: 8, background: tint(theme.colors.accent, 0.22), border: `1.5px solid ${tint(theme.colors.accent, 0.55)}`, fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 52, lineHeight: 1.45, display: "flex", alignItems: "center", gap: 16 }}>
                  {typing && shown === 0 ? (
                    <span style={{ display: "flex", gap: 10 }}>
                      {[0, 1, 2].map((i) => (<span key={i} style={{ width: 14, height: 14, borderRadius: 7, background: theme.colors.text, opacity: 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(frame / 4 - i)) }} />))}
                    </span>
                  ) : (
                    msg.slice(0, shown).join(" ")
                  )}
                </div>
                <div style={{ display: "flex", justifyContent: "flex-end", height: 52, marginTop: 6 }}>
                  <CheckMark size={52} p={check} sw={22} />
                </div>
              </div>
            </Glass>
          </Float>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
