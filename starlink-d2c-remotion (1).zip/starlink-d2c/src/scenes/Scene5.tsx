import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, tint } from "../theme";
import { lb } from "../timeline";
import { FR } from "../beats";
import { Entrance, MaskLine, Exit, Rings, useSpring, gradientText } from "../components/Anim";
import { Pill, SignalBars } from "../components/Ui";
import { TowerIcon, CrossMark } from "../components/Icons";
import { LandscapeLayer, REGION_W, PARALLAX } from "../components/Landscape";

// Style: Flat Vector landscape with parallax pan (mountains → forest → sea)
const REGIONS = ["পাহাড়", "জঙ্গল", "সমুদ্র"];

export const Scene5: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = FR.s5.regions.map((f) => lb(5, f));
  const tStuck = lb(5, FR.s5.stuck);
  const tTower = lb(5, FR.s5.tower);
  const move = Math.round(fps * 0.8);
  const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: theme.ease.inOut } as const;
  // camera arrives at region k exactly at its beat
  const cam =
    interpolate(frame, [t[1] - move, t[1]], [0, 1], clamp) * REGION_W +
    interpolate(frame, [t[2] - move, t[2]], [0, 1], clamp) * REGION_W;
  const pStuck = useSpring(tStuck, theme.spring.bouncy);
  const pTower = useSpring(tTower, theme.spring.smooth);
  const pPin = useSpring(t[0], theme.spring.smooth);

  return (
    <AbsoluteFill>
      {/* parallax layers */}
      {(["far", "mid", "near"] as const).map((l, i) => (
        <div key={l} style={{ position: "absolute", left: 0, top: 0, width: REGION_W * 3, height: 1080, transform: `translateX(${-cam * PARALLAX[l]}px)` }}>
          <LandscapeLayer layer={l} />
        </div>
      ))}

      {/* title: দুর্গম + region word */}
      <div style={{ position: "absolute", left: 150, top: 120, fontFamily: theme.fonts.display, fontWeight: theme.weight.display }}>
        <Entrance delay={Math.max(0, t[0] - 2)} y={30} config={theme.spring.snappy}>
          <Pill>দুর্গম</Pill>
        </Entrance>
        <div style={{ position: "relative", height: 230, marginTop: 6 }}>
          {REGIONS.map((r, k) => {
            const start = t[k];
            const end = k < 2 ? t[k + 1] - move + 6 : undefined;
            const word = (
              <MaskLine delay={start} style={{ fontSize: theme.size.hero * 0.95, lineHeight: 1.3 }}>
                <span style={{ display: "inline-block", ...gradientText }}>{r}</span>
              </MaskLine>
            );
            return (
              <div key={r} style={{ position: "absolute", left: 0, top: 0 }}>
                {end === undefined ? word : <Exit at={end} style={{ position: "relative", inset: "auto" }}>{word}</Exit>}
              </div>
            );
          })}
        </div>
      </div>

      {/* step chips (equal spacing across the cue) */}
      <div style={{ position: "absolute", left: 150, bottom: 90, display: "flex", gap: 18 }}>
        {REGIONS.map((r, k) => {
          const on = frame >= t[k];
          return (
            <Entrance key={r} delay={t[k]} y={20} config={theme.spring.snappy}>
              <Pill style={{ background: on ? tint(theme.colors.accent, 0.2) : theme.colors.glass, border: `1.5px solid ${on ? tint(theme.colors.accent, 0.6) : theme.colors.glassBorder}` }}>{r}</Pill>
            </Entrance>
          );
        })}
      </div>

      {/* stranded pin: phone dot, no signal */}
      <div style={{ position: "absolute", left: 960, top: 640, opacity: pPin, transform: `scale(${interpolate(pPin, [0, 1], [0.6, 1])})` }}>
        <div style={{ position: "relative", width: 0, height: 0 }}>
          <Rings at={tStuck} count={3} size={520} period={1.8} />
          <div style={{ position: "absolute", left: -76, top: -76, width: 152, height: 152, borderRadius: "50%", background: theme.colors.glassStrong, border: `2px solid ${theme.colors.glassBorder}`, backdropFilter: "blur(14px)", display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${1 + (pStuck - 1) * 0.1})` }}>
            <div style={{ position: "relative" }}>
              <SignalBars level={0} size={64} />
              <div style={{ position: "absolute", inset: -14, display: "flex", alignItems: "center", justifyContent: "center", opacity: Math.min(1, pStuck) }}>
                <CrossMark size={92} p={Math.min(1, pStuck)} color={theme.colors.text} sw={20} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Tower, far right horizon */}
      <div style={{ position: "absolute", right: 170, top: 190, opacity: pTower * 0.95, transform: `translateX(${interpolate(pTower, [0, 1], [90, 0])}px)`, textAlign: "center" }}>
        <TowerIcon size={300} color={theme.colors.textDim} accent={theme.colors.textFaint} />
        <div style={{ marginTop: -10 }}><Pill>Mobile Tower</Pill></div>
      </div>
    </AbsoluteFill>
  );
};
