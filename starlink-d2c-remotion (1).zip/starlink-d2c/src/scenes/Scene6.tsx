import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, tint } from "../theme";
import { lb } from "../timeline";
import { FR } from "../beats";
import { Words, Entrance, Float, Exit, Rings, useSpring, useEase, gradientText } from "../components/Anim";
import { PhoneMockup, Pill } from "../components/Ui";
import { Satellite, TowerIcon } from "../components/Icons";
import { LandscapeLayer, REGION_W } from "../components/Landscape";

// Style: Statement (tower gone) → Line-Draw path (phone ⇢ satellite)
const PHONE_A = { x: 960, y: 700 }; // alert position (centre)
const PHONE_B = { x: 470, y: 720 }; // link position
const SAT = { x: 1480, y: 250 };

export const Scene6: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tCross = lb(6, FR.s6.cross);
  const tAlert = lb(6, FR.s6.alert);
  const tPath = lb(6, FR.s6.path);
  const tStar = lb(6, FR.s6.starlink);

  const strike = useEase(tCross + 8, 0.4, theme.ease.out);
  const pPhone = useSpring(tAlert + 4, theme.spring.bouncy);
  const slide = useEase(tPath - 4, 0.7, theme.ease.inOut);
  const pSat = useSpring(tPath + 6, theme.spring.bouncy);
  const draw = useEase(tPath + 10, 1.1, theme.ease.inOut);
  const pLabel = useSpring(tPath + 22, theme.spring.snappy);
  const pStar = useSpring(tStar, theme.spring.bouncy);

  const px = interpolate(slide, [0, 1], [PHONE_A.x, PHONE_B.x]);
  const py = interpolate(slide, [0, 1], [PHONE_A.y, PHONE_B.y]);

  // quadratic arc phone → satellite
  const x0 = PHONE_B.x + 20, y0 = PHONE_B.y - 120;
  const x1 = SAT.x - 40, y1 = SAT.y + 130;
  const cx = 560, cy = 220;
  const d = `M${x0} ${y0} Q${cx} ${cy} ${x1} ${y1}`;
  // packet position along the arc
  const u = ((frame - tPath - 24) % (fps * 1.4)) / (fps * 1.4);
  const uu = frame > tPath + 24 ? theme.ease.inOut(Math.max(0, u)) : -1;
  const bx = (1 - uu) * (1 - uu) * x0 + 2 * (1 - uu) * uu * cx + uu * uu * x1;
  const by = (1 - uu) * (1 - uu) * y0 + 2 * (1 - uu) * uu * cy + uu * uu * y1;

  return (
    <AbsoluteFill>
      {/* low ridge silhouette keeps the "remote place" feeling from the previous scene */}
      <div style={{ position: "absolute", left: -REGION_W * 0, top: 0, width: REGION_W, height: 1080, opacity: 0.9 }}>
        <LandscapeLayer layer="near" />
      </div>

      {/* ---------- beat 1: tower gone ---------- */}
      <Exit at={tAlert - 4}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 90, marginTop: -40 }}>
            <Entrance delay={tCross} y={50} config={theme.spring.bouncy}>
              <div style={{ position: "relative", width: 420, height: 420 }}>
                <Float amp={5} speed={26}><TowerIcon size={420} color={theme.colors.textDim} accent={theme.colors.textFaint} /></Float>
                <svg width={420} height={420} viewBox="0 0 420 420" style={{ position: "absolute", inset: 0, overflow: "visible" }}>
                  <path d="M50 380 L370 40" stroke={theme.colors.accent} strokeWidth={22} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - strike} style={{ filter: `drop-shadow(0 0 14px ${theme.colors.accent})` }} />
                </svg>
              </div>
            </Entrance>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 14 }}>
              <Entrance delay={tCross + 2} y={30} config={theme.spring.snappy}><Pill>Mobile Tower</Pill></Entrance>
              <Words delay={tCross + 4} per={4} align="flex-start" style={{ fontSize: theme.size.hero }} words={[{ t: "নেই", pop: true }]} />
            </div>
          </div>
        </AbsoluteFill>
      </Exit>

      {/* ---------- beat 2: emergency ---------- */}
      <Exit at={tPath - 6} style={{ pointerEvents: "none" }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 150 }}>
          <Words delay={tAlert} per={5} gap={46} style={{ fontSize: theme.size.h1 }} words={[{ t: "ঠিক", style: { color: theme.colors.textDim } }, { t: "এমন", style: { color: theme.colors.textDim } }, { t: "জরুরি", style: gradientText, pop: true }, { t: "মুহূর্তে", style: gradientText, pop: true }]} />
        </div>
      </Exit>

      {/* phone: appears centre with alert rings, then slides to link position */}
      <div style={{ position: "absolute", left: px, top: py, opacity: Math.min(1, pPhone * 1.5), transform: `translate(-50%, -50%) scale(${interpolate(pPhone, [0, 1], [0.5, 1])})` }}>
        <div style={{ position: "absolute", left: "50%", top: "50%", width: 0, height: 0 }}>
          <Rings at={tAlert + 6} count={3} size={600} period={1.5} />
        </div>
        <Float amp={5} speed={28}><PhoneMockup width={150} /></Float>
      </div>

      {/* ---------- beat 3: alternative path ---------- */}
      <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", overflow: "visible" }}>
        <path d={d} fill="none" stroke={theme.colors.accent} strokeWidth={7} strokeLinecap="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - draw} style={{ filter: `drop-shadow(0 0 12px ${theme.colors.accent})` }} />
        {uu >= 0 && <circle cx={bx} cy={by} r={13} fill={theme.colors.text} style={{ filter: `drop-shadow(0 0 14px ${theme.colors.accent})` }} />}
      </svg>
      <div style={{ position: "absolute", left: SAT.x - 130, top: SAT.y - 130, opacity: Math.min(1, pSat * 1.5), transform: `scale(${pSat})` }}>
        <Float amp={9} speed={27}><Satellite size={260} /></Float>
      </div>
      <div style={{ position: "absolute", left: 760, top: 470, opacity: pLabel, transform: `translateY(${interpolate(pLabel, [0, 1], [30, 0])}px) scale(${interpolate(pLabel, [0, 1], [0.9, 1])})` }}>
        <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.h2, lineHeight: 1.3 }}>বিকল্প পথ</div>
      </div>
      <div style={{ position: "absolute", left: SAT.x - 120, top: SAT.y + 150, width: 240, textAlign: "center", opacity: pStar, transform: `scale(${interpolate(pStar, [0, 1], [0.7, 1])})` }}>
        <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.h3, lineHeight: 1.3, ...gradientText }}>Starlink</div>
      </div>
    </AbsoluteFill>
  );
};
