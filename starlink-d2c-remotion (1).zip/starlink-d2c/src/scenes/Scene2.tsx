import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, tint } from "../theme";
import { lb } from "../timeline";
import { FR } from "../beats";
import { Words, Entrance, MaskLine, gradientText, Float, Exit, Rings, Beam, useSpring, useEase } from "../components/Anim";
import { PhoneMockup, Glass } from "../components/Ui";
import { WifiIcon, AntennaIcon } from "../components/Icons";

// Style: Statement Card (no high-speed internet) → Before/After-style zoom lens (tiny antenna)
export const Scene2: React.FC = () => {
  const tWifi = lb(2, FR.s2.wifi);
  const tStrike = lb(2, FR.s2.strike);
  const tLens = lb(2, FR.s2.lens);
  const tSmall = lb(2, FR.s2.small);
  const pIcon = useSpring(tWifi + 2, theme.spring.bouncy);
  const strike = useEase(tStrike, 0.45, theme.ease.out);
  const pPhone = useSpring(tLens, theme.spring.smooth);
  const pLens = useSpring(tLens + 6, theme.spring.bouncy);
  const pAnt = useSpring(tLens + 14, theme.spring.snappy);

  return (
    <AbsoluteFill>
      {/* ---------- Phase A: statement ---------- */}
      <Exit at={tLens - 2}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 30, marginTop: -20 }}>
            <div style={{ position: "relative", width: 330, height: 330, opacity: pIcon, transform: `scale(${interpolate(pIcon, [0, 1], [0.6, 1])})` }}>
              <Float amp={6} speed={26}><WifiIcon size={330} sw={14} /></Float>
              {/* strike-through drawn over the icon */}
              <svg width={330} height={330} viewBox="0 0 330 330" style={{ position: "absolute", inset: 0, overflow: "visible" }}>
                <path d="M30 300 L300 30" stroke={theme.colors.accent} strokeWidth={20} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - strike} style={{ filter: `drop-shadow(0 0 14px ${theme.colors.accent})` }} />
              </svg>
            </div>
            <Words delay={tWifi + 4} per={4} gap={34} style={{ fontSize: theme.size.h1 }} words={[{ t: "উচ্চ" }, { t: "শক্তির" }, { t: "Internet", style: gradientText }]} />
            <Entrance delay={tStrike} y={30} config={theme.spring.snappy} style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.h3, color: theme.colors.textDim }}>
              পাবেন না
            </Entrance>
          </div>
        </AbsoluteFill>
      </Exit>

      {/* ---------- Phase B: tiny antenna under the lens ---------- */}
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 140, top: 330, fontFamily: theme.fonts.display, fontWeight: theme.weight.display }}>
          <MaskLine delay={tLens + 2} style={{ fontSize: theme.size.h3, color: theme.colors.textDim, lineHeight: 1.3 }}>সাধারণ ফোনের</MaskLine>
          <MaskLine delay={tLens + 8} style={{ fontSize: 120, lineHeight: 1.3 }}>Antenna</MaskLine>
          <Entrance delay={tSmall} y={50} from={0.7} config={theme.spring.bouncy} style={{ transformOrigin: "left center" }}>
            <div style={{ fontSize: theme.size.hero * 0.85, lineHeight: 1.25, ...gradientText, filter: `drop-shadow(0 0 36px ${theme.colors.glow})` }}>অনেক ছোট</div>
          </Entrance>
        </div>

        {/* phone (small) */}
        <div style={{ position: "absolute", left: 1010, top: 330, opacity: pPhone, transform: `translateY(${interpolate(pPhone, [0, 1], [70, 0])}px) rotate(-6deg)` }}>
          <Float amp={7} speed={31}>
            <PhoneMockup width={230}>
              <div style={{ position: "absolute", top: 70, right: 34, width: 18, height: 18, borderRadius: 9, background: theme.colors.accent, boxShadow: `0 0 24px ${theme.colors.accent}`, zIndex: 4 }} />
            </PhoneMockup>
          </Float>
        </div>

        {/* lens */}
        <div style={{ position: "absolute", left: 1330, top: 190, width: 480, height: 480, opacity: Math.min(1, pLens * 1.5), transform: `scale(${pLens})` }}>
          <Glass style={{ position: "relative", width: 480, height: 480, borderRadius: 240, display: "flex", alignItems: "center", justifyContent: "center", border: `3px solid ${tint(theme.colors.accent, 0.6)}` }}>
            <div style={{ position: "absolute", left: "50%", top: "50%", width: 0, height: 0 }}><Rings at={tLens + 18} count={2} size={560} period={2} /></div>
            <div style={{ opacity: pAnt, transform: `scale(${interpolate(pAnt, [0, 1], [0.5, 1])})` }}>
              <Float amp={5} speed={24}><AntennaIcon size={250} /></Float>
            </div>
          </Glass>
        </div>
        <Beam a={[1222, 420]} b={[1340, 410]} at={tLens + 6} secs={0.5} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
