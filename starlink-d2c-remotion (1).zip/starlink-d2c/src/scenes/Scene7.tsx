import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, tint } from "../theme";
import { lb } from "../timeline";
import { FR } from "../beats";
import { Words, Entrance, Float, Exit, Rings, useSpring, useEase, gradientText } from "../components/Anim";
import { Glass, Pill } from "../components/Ui";
import { Satellite, ThumbUp, Bell, Cursor } from "../components/Icons";

// Style: Statement Card (title lockup) → clean CTA (Like + Subscribe)
export const Scene7: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tTitle = lb(7, FR.s7.title);
  const tCta = lb(7, FR.s7.cta);
  const tLike = lb(7, FR.s7.like);
  const tSub = lb(7, FR.s7.sub);

  const pSat = useSpring(tTitle + 2, theme.spring.bouncy);
  const pHead = useSpring(tCta, theme.spring.smooth);
  const pLike = useSpring(tCta + 8, theme.spring.bouncy);
  const pSubBtn = useSpring(tCta + 14, theme.spring.bouncy);

  // cursor path: rests → Like (press) → Subscribe (press)
  const pressDur = Math.round(fps * 0.35);
  const toLike = useEase(tLike - Math.round(fps * 0.5), 0.5, theme.ease.inOut);
  const toSub = useEase(tSub - Math.round(fps * 0.45), 0.45, theme.ease.inOut);
  const cx = interpolate(toLike, [0, 1], [1500, 650]) + interpolate(toSub, [0, 1], [0, 640]);
  const cy = interpolate(toLike, [0, 1], [820, 640]) + interpolate(toSub, [0, 1], [0, 0]);
  const press = (t: number) => interpolate(frame, [t, t + 4, t + pressDur], [1, 0.9, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const likeOn = frame >= tLike;
  const subOn = frame >= tSub;
  const pLikeOn = useSpring(tLike, theme.spring.bouncy);
  const pSubOn = useSpring(tSub, theme.spring.bouncy);
  const cursorOp = interpolate(frame, [tLike - Math.round(fps * 0.6), tLike - Math.round(fps * 0.4)], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  return (
    <AbsoluteFill>
      {/* ---------- Phase A: title lockup ---------- */}
      <Exit at={tCta - 2}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, marginTop: -30 }}>
            <div style={{ opacity: Math.min(1, pSat * 1.5), transform: `scale(${interpolate(pSat, [0, 1], [0.5, 1])})` }}>
              <Float amp={8} speed={26}><Satellite size={230} /></Float>
            </div>
            <Words delay={tTitle + 3} per={5} gap={50} style={{ fontSize: 230 }} words={[{ t: "Starlink", style: gradientText, pop: true }]} />
            <Words delay={tTitle + 12} per={5} gap={46} style={{ fontSize: theme.size.h1 }} words={[{ t: "Direct" }, { t: "to" }, { t: "Cell" , pop: true }]} />
            <Entrance delay={tTitle + 26} y={30} config={theme.spring.snappy} style={{ marginTop: 10 }}>
              <Pill>প্রযুক্তি</Pill>
            </Entrance>
          </div>
        </AbsoluteFill>
      </Exit>

      {/* ---------- Phase B: CTA ---------- */}
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 0, right: 0, top: 120, textAlign: "center", opacity: pHead, transform: `translateY(${interpolate(pHead, [0, 1], [50, 0])}px)` }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 34 }}>
            <Satellite size={130} />
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.h2, lineHeight: 1.3 }}>Starlink Direct to Cell</div>
          </div>
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.body, fontSize: theme.size.h3, color: theme.colors.textDim, lineHeight: 1.3, marginTop: 40 }}>এমন আরও Video পেতে</div>
        </div>

        <div style={{ position: "absolute", left: 0, right: 0, top: 560, display: "flex", justifyContent: "center", gap: 80 }}>
          {/* Like */}
          <div style={{ opacity: Math.min(1, pLike * 1.5), transform: `translateY(${interpolate(pLike, [0, 1], [70, 0])}px) scale(${interpolate(pLike, [0, 1], [0.8, 1]) * press(tLike)})` }}>
            <Float amp={5} speed={30}>
              <Glass style={{ width: 520, height: 170, borderRadius: 85, display: "flex", alignItems: "center", justifyContent: "center", gap: 28, background: likeOn ? tint(theme.colors.accent, 0.22) : undefined, border: `2px solid ${likeOn ? tint(theme.colors.accent, 0.7) : theme.colors.glassBorder}` }}>
                <div style={{ transform: `rotate(${likeOn ? interpolate(pLikeOn, [0, 1], [-25, 0]) : 0}deg) scale(${likeOn ? interpolate(pLikeOn, [0, 1], [0.7, 1.1]) : 1})` }}>
                  <ThumbUp size={86} color={likeOn ? theme.colors.accent : theme.colors.text} />
                </div>
                <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.h3, lineHeight: 1.3 }}>Like</div>
              </Glass>
            </Float>
          </div>
          {/* Subscribe */}
          <div style={{ opacity: Math.min(1, pSubBtn * 1.5), transform: `translateY(${interpolate(pSubBtn, [0, 1], [70, 0])}px) scale(${interpolate(pSubBtn, [0, 1], [0.8, 1]) * press(tSub)})` }}>
            <Float amp={5} speed={30} phase={1.5}>
              <div style={{ width: 640, height: 170, borderRadius: 85, display: "flex", alignItems: "center", justifyContent: "center", gap: 28, background: subOn ? theme.colors.glassStrong : theme.colors.primary, border: `2px solid ${subOn ? theme.colors.glassBorder : tint(theme.colors.text, 0.35)}`, boxShadow: subOn ? theme.shadow.soft : `0 0 70px ${theme.colors.glow}, ${theme.shadow.soft}` }}>
                <div style={{ transform: `rotate(${subOn ? Math.sin((frame - tSub) / 2.2) * 18 * Math.max(0, 1 - (frame - tSub) / 22) : 0}deg)`, transformOrigin: "50% 10%" }}>
                  <Bell size={86} color={theme.colors.text} />
                </div>
                <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.h3, lineHeight: 1.3 }}>{subOn ? "Subscribed" : "Subscribe"}</div>
              </div>
            </Float>
          </div>
        </div>

        <div style={{ position: "absolute", left: cx, top: cy, opacity: cursorOp, transform: `scale(${press(subOn ? tSub : tLike)})`, filter: "drop-shadow(0 8px 14px rgba(0,0,0,0.5))" }}>
          <Cursor size={84} />
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
