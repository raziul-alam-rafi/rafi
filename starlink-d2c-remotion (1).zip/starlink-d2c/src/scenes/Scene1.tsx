import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { theme, tint } from "../theme";
import { lb } from "../timeline";
import { FR } from "../beats";
import { Words, Entrance, MaskLine, Sweep, gradientText, Float, Exit, Rings, Beam, useSpring } from "../components/Anim";
import { PhoneMockup, SignalBars } from "../components/Ui";
import { Satellite } from "../components/Icons";

// Style: Kinetic Typography (hook) → Glossy UI Mockup (phone + satellite link)
export const Scene1: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tLine2 = lb(1, FR.s1.line2);
  const tOut = lb(1, FR.s1.kineticOut);
  const tPhone = lb(1, FR.s1.phone);
  const tStar = lb(1, FR.s1.starlink);
  const pPhone = useSpring(tPhone, theme.spring.smooth);
  const pSat = useSpring(tPhone + 8, theme.spring.bouncy);
  const hookPulse = interpolate(frame, [0, 14], [0.7, 1], { easing: theme.ease.out, extrapolateRight: "clamp" });

  return (
    <AbsoluteFill>
      {/* ---------- Phase A: kinetic hook ---------- */}
      <Exit at={tOut}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
          <div style={{ position: "absolute", left: "50%", top: "46%", width: 0, height: 0 }}>
            <Rings at={2} count={3} size={1100} period={2.2} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 28, transform: `scale(${hookPulse})` }}>
            <Words
              delay={0}
              per={5}
              gap={56}
              style={{ fontSize: theme.size.hero }}
              words={[{ t: "এখন", pop: true }, { t: "একটু", pop: true }, { t: "থামুন।", pop: true }]}
            />
            <div style={{ display: "flex", alignItems: "center", columnGap: 40, fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.h1, lineHeight: 1.3 }}>
              <Entrance delay={tLine2} y={50} config={theme.spring.snappy} style={{ color: theme.colors.textDim }}>একটা</Entrance>
              <Entrance delay={tLine2 + 5} y={50} config={theme.spring.bouncy}>
                <Sweep delay={tLine2 + 12}>খারাপ খবর</Sweep>
              </Entrance>
            </div>
          </div>
        </AbsoluteFill>
      </Exit>

      {/* ---------- Phase B: phone + satellite ---------- */}
      <AbsoluteFill>
        {/* left: text */}
        <div style={{ position: "absolute", left: 150, top: 330, width: 900, fontFamily: theme.fonts.display, fontWeight: theme.weight.display }}>
          <MaskLine delay={tPhone} style={{ fontSize: theme.size.h2, color: theme.colors.text, lineHeight: 1.3 }}>মোবাইলে সরাসরি</MaskLine>
          <Entrance delay={tStar} y={60} from={0.8} config={theme.spring.bouncy} style={{ transformOrigin: "left center" }}>
            <div style={{ fontSize: 230, lineHeight: 1.15, ...gradientText, filter: `drop-shadow(0 0 40px ${theme.colors.glow})` }}>Starlink</div>
          </Entrance>
        </div>

        {/* right: phone with link */}
        <div style={{ position: "absolute", left: 1330, top: 540, width: 0, height: 0 }}>
          <div style={{ position: "absolute", left: -170, top: -345, opacity: pPhone, transform: `translateY(${interpolate(pPhone, [0, 1], [90, 0])}px) rotate(${interpolate(pPhone, [0, 1], [8, -4])}deg) scale(${interpolate(pPhone, [0, 1], [0.85, 1])})` }}>
            <Float amp={8} speed={34}>
              <PhoneMockup width={340}>
                <div style={{ position: "absolute", top: 34, left: 28, right: 28, display: "flex", justifyContent: "space-between", alignItems: "center", zIndex: 4 }}>
                  <SignalBars level={3} size={30} />
                  <div style={{ width: 70, height: 20, borderRadius: 10, background: theme.colors.glassBorder }} />
                </div>
                <div style={{ position: "absolute", inset: 0 }}>
                  <div style={{ position: "absolute", left: "50%", top: "50%", width: 0, height: 0 }}>
                    <Rings at={tPhone + 14} count={3} size={420} period={1.8} />
                  </div>
                  <div style={{ position: "absolute", left: "50%", top: "50%", transform: "translate(-50%, -50%)" }}>
                    <Satellite size={190} />
                  </div>
                </div>
              </PhoneMockup>
            </Float>
          </div>
        </div>

        {/* satellite above, beam down to phone */}
        <div style={{ position: "absolute", left: 1560, top: 130, opacity: Math.min(1, pSat * 1.5), transform: `scale(${pSat})` }}>
          <Float amp={10} speed={28} phase={1}><Satellite size={200} /></Float>
        </div>
        <Beam a={[1620, 280]} b={[1380, 350]} at={tPhone + 12} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
