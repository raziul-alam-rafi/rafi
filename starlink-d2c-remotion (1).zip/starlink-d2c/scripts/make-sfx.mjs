// Synthesizes the SFX kit (16-bit mono WAV, 44.1 kHz) into public/sfx. Deterministic, no downloads.
// Sounds: whoosh, pop, click, chime, thud — all soft, short, low-passed, lightly reverbed, peak-normalized.
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const OUT = path.join(process.cwd(), "public", "sfx");
fs.mkdirSync(OUT, { recursive: true });

// seeded noise so output is identical every run
let seed = 1234567;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const buf = (sec) => new Float32Array(Math.floor(sec * SR));
const env = (t, a, d) => Math.min(1, t / a) * Math.exp(-t / d);

const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y += a * (v - y)));
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
};
const bandpassSweep = (x, f0, f1, q = 1.4) => {
  // state-variable filter with sweeping centre frequency
  let low = 0, band = 0;
  const out = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) {
    const p = i / x.length;
    const fc = f0 * Math.pow(f1 / f0, p);
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    low += f * band;
    const high = x[i] - low - band / q;
    band += f * high;
    out[i] = band;
  }
  return out;
};
const reverb = (x, mix = 0.16) => {
  const taps = [[0.023, 0.5], [0.041, 0.35], [0.067, 0.25], [0.097, 0.15]];
  const out = new Float32Array(x.length + Math.floor(0.12 * SR));
  x.forEach((v, i) => (out[i] += v));
  for (const [dt, g] of taps) {
    const d = Math.floor(dt * SR);
    for (let i = 0; i < x.length; i++) out[i + d] += x[i] * g * mix * 2.2;
  }
  return out;
};
// 1 ms click-free fade-in, 8 ms fade-out (keeps transients intact)
const fade = (x) => {
  const nIn = Math.floor(0.001 * SR), nOut = Math.floor(0.008 * SR);
  for (let i = 0; i < nIn && i < x.length; i++) x[i] *= i / nIn;
  for (let i = 0; i < nOut && i < x.length; i++) x[x.length - 1 - i] *= i / nOut;
  return x;
};
const normalize = (x, peak = 0.8) => {
  let m = 0;
  for (const v of x) m = Math.max(m, Math.abs(v));
  const g = peak / (m || 1);
  return x.map((v) => v * g);
};

const sounds = {
  // pop: sine with quick downward pitch glide + tiny envelope
  pop: () => {
    const x = buf(0.22);
    let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const f = 140 + 520 * Math.exp(-t / 0.028);
      ph += (2 * Math.PI * f) / SR;
      x[i] = Math.sin(ph) * env(t, 0.003, 0.05) + 0.25 * Math.sin(ph * 2) * env(t, 0.003, 0.02);
    }
    return lowpass(x, 3200);
  },
  // click: short high-passed noise burst + faint tick body
  click: () => {
    const x = buf(0.09);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      x[i] = rnd() * env(t, 0.0008, 0.011) + 0.35 * Math.sin(2 * Math.PI * 1900 * t) * env(t, 0.001, 0.008);
    }
    return lowpass(highpass(x, 1400), 6500);
  },
  // whoosh: band-passed noise sweep, fade in/out
  whoosh: () => {
    const n = buf(0.62);
    for (let i = 0; i < n.length; i++) n[i] = rnd();
    const y = bandpassSweep(n, 450, 3200, 1.1);
    for (let i = 0; i < y.length; i++) {
      const p = i / y.length;
      y[i] *= Math.pow(Math.sin(Math.PI * Math.pow(p, 0.8)), 2);
    }
    return lowpass(y, 5200);
  },
  // chime: soft pluck with gentle overtones and short decay
  chime: () => {
    const x = buf(0.5);
    const f0 = 880;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const s =
        Math.sin(2 * Math.PI * f0 * t) * Math.exp(-t / 0.16) +
        0.35 * Math.sin(2 * Math.PI * f0 * 2.01 * t) * Math.exp(-t / 0.09) +
        0.18 * Math.sin(2 * Math.PI * f0 * 3.02 * t) * Math.exp(-t / 0.05);
      x[i] = s * Math.min(1, t / 0.004);
    }
    return lowpass(x, 4200);
  },
  // thud: very soft low hit (hook / key message)
  thud: () => {
    const x = buf(0.34);
    let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const f = 48 + 70 * Math.exp(-t / 0.05);
      ph += (2 * Math.PI * f) / SR;
      x[i] = Math.sin(ph) * env(t, 0.006, 0.09);
    }
    return lowpass(x, 700);
  },
};

const writeWav = (name, data) => {
  const pcm = Buffer.alloc(44 + data.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + data.length * 2, 4); pcm.write("WAVE", 8);
  pcm.write("fmt ", 12); pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34);
  pcm.write("data", 36); pcm.writeUInt32LE(data.length * 2, 40);
  data.forEach((v, i) => pcm.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(v * 32767))), 44 + i * 2));
  fs.writeFileSync(path.join(OUT, name + ".wav"), pcm);
};

const report = [];
for (const [name, gen] of Object.entries(sounds)) {
  let x = gen();
  x = reverb(x, name === "click" ? 0.06 : 0.14);
  x = lowpass(x, name === "click" ? 7000 : 5500);
  x = normalize(fade(x), 0.8); // fade first, then normalize so every peak is identical
  writeWav(name, x);
  let peak = 0, clipped = 0;
  for (const v of x) { peak = Math.max(peak, Math.abs(v)); if (Math.abs(v) >= 0.999) clipped++; }
  report.push({ name, sec: +(x.length / SR).toFixed(3), peak: +peak.toFixed(3), clipped });
}
console.table(report);
