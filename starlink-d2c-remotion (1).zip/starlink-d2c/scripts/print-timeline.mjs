// Prints scene boundaries computed from the SRT (sanity check).
import fs from "node:fs";
const raw = fs.readFileSync("public/script.srt", "utf8").replace(/\r/g, "");
const ms = (t) => { const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/); return ((+m[1]*60 + +m[2])*60 + +m[3])*1000 + +m[4]; };
const cues = raw.split(/\n\s*\n/).map(b => b.trim().split("\n")).filter(l => l.length > 1 && l[1].includes("-->")).map(l => { const [a,b]=l[1].split("-->"); return { n:+l[0], s:ms(a), e:ms(b) }; });
const f = (x) => Math.round(x/1000*30);
console.log("cues:", cues.map(c => `${c.n}: f${f(c.s)}–f${f(c.e)}`).join(" | "));
console.log("total frames:", f(cues.at(-1).e), "=", (cues.at(-1).e/1000).toFixed(2), "s");
