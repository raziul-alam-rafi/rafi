1) npm install
2) npx remotion studio src/index.ts   (or: npm run studio)
3) npx remotion render src/index.ts Main out/video.mp4
Optional: put narration at public/voiceover.mp3 (plays in Studio; set VOICEOVER_IN_RENDER=true in src/config.ts to bake into render).
